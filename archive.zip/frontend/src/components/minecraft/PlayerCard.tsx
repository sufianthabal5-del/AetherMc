import { useEffect, useRef } from "react";
import { PlayerRow } from "../../types";
import { hours } from "../../lib/money";
import { SITE } from "../../constants/site";

export default function PlayerCard({ p }: { p: PlayerRow }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!, x = c.getContext("2d")!;
    const draw = (logo?: HTMLImageElement) => {
      const g = x.createLinearGradient(0, 0, c.width, c.height);
      g.addColorStop(0, "#ff8a1f"); g.addColorStop(1, "#ffd23a");
      x.fillStyle = g; x.fillRect(0, 0, c.width, c.height);
      x.fillStyle = "rgba(20,18,48,.88)"; x.fillRect(20, 20, c.width - 40, c.height - 40);
      x.fillStyle = "#fff"; x.font = "bold 44px 'Pixelify Sans', monospace"; x.fillText(p.name, 44, 84);
      x.font = "22px 'Nunito Sans', sans-serif"; x.fillStyle = "#ffd23a";
      const rows = [["Playtime", hours(p.playtime_seconds) + " h"], ["Kills", String(p.kills)], ["Deaths", String(p.deaths)], ["Mob kills", String(p.mob_kills)], ["Money", Math.round(p.balance).toLocaleString("en")]];
      rows.forEach(([k, v], i) => { x.fillStyle = "#c9c5ff"; x.fillText(k, 44, 138 + i * 34); x.fillStyle = "#fff"; x.fillText(v, 200, 138 + i * 34); });
      x.fillStyle = "#c9c5ff"; x.font = "16px 'Nunito Sans', sans-serif"; x.fillText(SITE.name + " · " + SITE.ip, 44, c.height - 36);
      if (logo) x.drawImage(logo, c.width - 150, 40, 100, 100);
    };
    draw();
    const img = new Image();
    img.onload = () => draw(img);
    img.src = "/assets/logo/logo.webp";
  }, [p]);
  const download = () => ref.current!.toBlob((b) => { if (!b) return; const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = p.name + "-aethermc-card.png"; a.click(); URL.revokeObjectURL(a.href); });
  return (
    <div className="card">
      <canvas ref={ref} width={600} height={340} style={{ width: "100%", maxWidth: 600, borderRadius: 12 }} aria-label={"Player card for " + p.name} />
      <p><button className="btn" onClick={download}>Download card</button></p>
    </div>
  );
}
