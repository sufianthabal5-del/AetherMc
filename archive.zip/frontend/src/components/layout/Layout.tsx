import { NavLink, Outlet } from "react-router-dom";
import { NAV, SITE } from "../../constants/site";
import { useAuth } from "../../contexts/AuthContext";
import { useCart } from "../../contexts/CartContext";
export default function Layout() {
  const { user, admin } = useAuth();
  const { count } = useCart();
  return (
    <>
      <nav className="nav" aria-label="Main">
        <img src="/assets/logo/logo.webp" alt={SITE.name + " logo"} />
        {NAV.map((n) => <NavLink key={n.to} to={n.to} end={n.to === "/"}>{n.label}</NavLink>)}
        <NavLink to="/checkout" className="push">Cart ({count})</NavLink>
        {admin && <NavLink to="/admin">Admin</NavLink>}
        <NavLink to={user ? "/account" : "/login"}>{user ? "Account" : "Login"}</NavLink>
      </nav>
      <main><Outlet /></main>
      <footer>© {new Date().getFullYear()} {SITE.name}. Not affiliated with Mojang or Microsoft.</footer>
    </>
  );
}
