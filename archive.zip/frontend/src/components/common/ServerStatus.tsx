import { useEffect, useState } from "react";
import { getStatus } from "../../services/api";
import { ServerStatus as S } from "../../types";
export default function ServerStatus() {
  const [s, setS] = useState<S | null>(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    const load = () => getStatus().then((d) => { setS(d); setErr(""); }).catch((e) => setErr(e.message));
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, []);
  if (err) return <p className="muted">Status unavailable.</p>;
  const online = !!s && Date.now() - new Date(s.updated_at).getTime() < 180000;
  return <p className="status"><span className={online ? "dot on" : "dot"} />{online ? `Online: ${s!.players}/${s!.max_players} players` + (s!.version ? ` · ${s!.version}` : "") : "Offline or not syncing yet"}</p>;
}
