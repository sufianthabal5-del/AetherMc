import { useState } from "react";
import { SITE } from "../../constants/site";
export default function CopyIP() {
  const [label, setLabel] = useState("Copy IP");
  const copy = async () => {
    try { await navigator.clipboard.writeText(SITE.ip); setLabel("Copied"); setTimeout(() => setLabel("Copy IP"), 1500); }
    catch { setLabel(SITE.ip); }
  };
  return <div className="ip"><code>{SITE.ip}</code><button className="btn" onClick={copy}>{label}</button></div>;
}
