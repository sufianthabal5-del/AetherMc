import { useEffect, useState } from "react";
export function useData<T>(load: () => Promise<T>, initial: T, deps: unknown[] = []) {
  const [data, setData] = useState<T>(initial);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  useEffect(() => {
    let on = true;
    setLoading(true);
    load().then((d) => { if (on) { setData(d); setError(""); } })
      .catch((e) => { if (on) setError(e?.message ?? "Could not load data."); })
      .finally(() => { if (on) setLoading(false); });
    return () => { on = false; };
  }, deps);
  return { data, loading, error };
}
