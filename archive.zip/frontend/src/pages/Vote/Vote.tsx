import { getVoteSites } from "../../services/api";
import { useData } from "../../hooks/useData";
import { VoteSite } from "../../types";
export default function Vote() {
  const { data, loading } = useData(getVoteSites, [] as VoteSite[]);
  return (
    <>
      <h2>Vote</h2>
      <p className="muted">Vote on each site daily. Votes are recorded automatically by the server.</p>
      {!loading && !data.length && <p className="muted">No vote sites added yet.</p>}
      {data.map((s) => <div className="card" key={s.id}><h3>{s.name}</h3><a className="btn" href={s.url} target="_blank" rel="noopener noreferrer">Vote now</a></div>)}
    </>
  );
}
