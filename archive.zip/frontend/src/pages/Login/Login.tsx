import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
export default function Login() {
  const { loginGoogle, user } = useAuth();
  const nav = useNavigate();
  const [msg, setMsg] = useState("");
  useEffect(() => { if (user) nav("/account"); }, [user]);
  return (
    <>
      <h2>Log in</h2>
      <div className="card">
        <p>Sign in with Google to buy from the store and link your Minecraft account.</p>
        <button className="btn" onClick={async () => { const e = await loginGoogle(); if (e) setMsg(e); }}>Continue with Google</button>
        <p className="muted" role="status">{msg}</p>
      </div>
    </>
  );
}
