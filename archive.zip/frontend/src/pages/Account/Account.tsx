import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useData } from "../../hooks/useData";
import { createLinkCode, getMyLink, getMyOrders } from "../../services/api";
import { fmt } from "../../lib/money";
import { OrderRow } from "../../types";
import { SITE } from "../../constants/site";

export default function Account() {
  const { user, loading, loginGoogle, logout } = useAuth();
  const [tick, setTick] = useState(0);
  const [code, setCode] = useState("");
  const [msg, setMsg] = useState("");
  const link = useData(() => (user ? getMyLink(user.id) : Promise.resolve(null)), null as { mc_name: string } | null, [user?.id, tick]);
  const orders = useData(() => (user ? getMyOrders(user.id) : Promise.resolve([])), [] as OrderRow[], [user?.id, tick]);
  if (loading) return <p className="muted">Loading…</p>;
  if (!user) return <><h2>Account</h2><div className="card"><p>Log in to link your Minecraft account and see your orders.</p><button className="btn" onClick={() => loginGoogle()}>Continue with Google</button></div></>;
  const gen = async () => { try { setCode(await createLinkCode()); setMsg(""); } catch (e: any) { setMsg(e.message); } };
  return (
    <>
      <h2>Account</h2>
      <p className="muted">{user.email} · <button className="btn alt" onClick={logout}>Log out</button></p>
      <div className="card">
        <h3>Minecraft account</h3>
        {link.data ? <p>Linked to <strong>{link.data.mc_name}</strong>. <Link to={"/player/" + link.data.mc_name}>View your profile</Link></p> : <p className="muted">Not linked yet.</p>}
        <p>Join <code>{SITE.ip}</code>, then run the command below in game. Bedrock names start with <code>{SITE.floodgatePrefix}</code>.</p>
        <button className="btn" onClick={gen}>{link.data ? "Link a different account" : "Get link code"}</button>
        {code && <p>In game, type: <code>/link {code}</code> (valid 10 minutes) <button className="btn alt" onClick={() => setTick(tick + 1)}>I did it</button></p>}
        <p className="muted" role="status">{msg}</p>
      </div>
      <h3>My orders</h3>
      {!orders.data.length && <p className="muted">No orders yet.</p>}
      {orders.data.map((o) => (
        <div className="card" key={o.id}>
          <div className="row" style={{ borderTop: 0 }}><strong>{fmt(o.total, o.currency)}</strong><span className={"pill " + o.status}>{o.status}</span></div>
          <p>{o.order_items.map((i) => i.qty + "× " + i.name).join(", ")}</p>
          <p className="muted">Txn {o.txn_ref} · {new Date(o.created_at).toLocaleString()}</p>
          {o.status === "approved" && <p className="muted">Approved. Items are delivered when you are online in game.</p>}
          {o.admin_note && <p className="muted">Note: {o.admin_note}</p>}
        </div>
      ))}
    </>
  );
}
