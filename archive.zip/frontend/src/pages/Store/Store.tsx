import { Link } from "react-router-dom";
import { getProducts, getRates } from "../../services/api";
import { useData } from "../../hooks/useData";
import { useCart } from "../../contexts/CartContext";
import { CURRENCIES } from "../../constants/site";
import { fmt, unitPrice } from "../../lib/money";
import { Product, Rates } from "../../types";
const KINDS: [string, string][] = [["rank", "Ranks"], ["kit", "Kits"], ["coins", "Coins"], ["lifesteal", "LifeSteal"], ["bundle", "Bundles"]];
export default function Store() {
  const { data, loading, error } = useData(getProducts, [] as Product[]);
  const rates = useData(getRates, {} as Rates);
  const { currency, setCurrency, add, items, count } = useCart();
  return (
    <>
      <h2>Store</h2>
      <div className="row" style={{ borderTop: 0 }}>
        <label>Currency <select value={currency} onChange={(e) => setCurrency(e.target.value)}>{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</select></label>
        <Link className="btn" to="/checkout">Cart ({count})</Link>
      </div>
      {loading && <p className="muted">Loading…</p>}
      {error && <p className="muted">{error}</p>}
      {KINDS.map(([k, label]) => {
        const list = data.filter((p) => p.kind === k);
        if (!list.length) return null;
        return (
          <section key={k}>
            <h3 style={{ marginTop: 24 }}>{label}</h3>
            <div className="grid">
              {list.map((p) => {
                const u = unitPrice(p, currency, rates.data);
                return (
                  <div className="card" key={p.id}>
                    <h3>{p.name}</h3>
                    {p.discount_percent > 0 && <span className="pill">{p.discount_percent}% off</span>}
                    <div className="price">{u.was && <s className="muted" style={{ fontSize: 16, marginRight: 8 }}>{fmt(u.was, currency)}</s>}{fmt(u.now, currency)}</div>
                    {p.perks.length > 0 && <ul>{p.perks.map((x) => <li key={x}>{x}</li>)}</ul>}
                    <button className="btn" onClick={() => add(p.id)}>{items[p.id] ? `Add another (${items[p.id]})` : "Add to cart"}</button>
                  </div>
                );
              })}
            </div>
          </section>
        );
      })}
    </>
  );
}
