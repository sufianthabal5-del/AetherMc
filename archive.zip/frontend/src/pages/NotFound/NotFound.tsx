import { Link } from "react-router-dom";
export default function NotFound() {
  return <><h2>Page not found</h2><p className="muted">That page doesn’t exist.</p><Link className="btn" to="/">Back to home</Link></>;
}
