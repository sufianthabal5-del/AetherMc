import { Link } from "react-router-dom";
import CopyIP from "../../components/common/CopyIP";
import ServerStatus from "../../components/common/ServerStatus";
import { SITE } from "../../constants/site";
import { getAnnouncements } from "../../services/api";
import { useData } from "../../hooks/useData";
import { Announcement } from "../../types";
const CARDS = [["Store", "Ranks, kits and coins.", "/store"], ["Leaderboard", "See the top players.", "/leaderboard"], ["Vote", "Vote for rewards.", "/vote"], ["Discord", "Join the community.", "/discord"]];
export default function Home() {
  const news = useData(() => getAnnouncements(3), [] as Announcement[]);
  return (
    <>
      <section className="hero">
        <img src="/assets/logo/logo.webp" alt="" />
        <div>
          <h1>{SITE.name}</h1>
          <p className="lead">Survival for Java and Bedrock players, together in one world.</p>
          <CopyIP />
          <p className="muted">Bedrock port: {SITE.bedrockPort}</p>
          <ServerStatus />
        </div>
      </section>
      <div className="grid">
        {CARDS.map(([t, d, to]) => <div className="card" key={t}><h3>{t}</h3><p className="muted">{d}</p><Link className="btn alt" to={to}>Open</Link></div>)}
      </div>
      {news.data.length > 0 && <><h2 style={{ marginTop: 28 }}>Latest news</h2>{news.data.map((a) => <div className="card" key={a.id}><h3>{a.title}</h3><p>{a.body}</p></div>)}</>}
    </>
  );
}
