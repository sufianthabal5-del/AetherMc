import { getAnnouncements } from "../../services/api";
import { useData } from "../../hooks/useData";
import { Announcement } from "../../types";
export default function Announcements() {
  const { data, loading } = useData(() => getAnnouncements(30), [] as Announcement[]);
  return (
    <>
      <h2>News</h2>
      {!loading && !data.length && <p className="muted">No announcements yet.</p>}
      {data.map((a) => <div className="card" key={a.id}><h3>{a.title}</h3><p className="muted">{new Date(a.created_at).toLocaleDateString()}</p><p>{a.body}</p></div>)}
    </>
  );
}
