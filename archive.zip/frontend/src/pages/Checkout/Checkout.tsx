import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { couponPercent, db, getMyLink, getPaymentMethods, getProducts, getRates, notifyOrder, placeOrder } from "../../services/api";
import { useData } from "../../hooks/useData";
import { useCart } from "../../contexts/CartContext";
import { useAuth } from "../../contexts/AuthContext";
import { CURRENCIES } from "../../constants/site";
import { fmt, unitPrice } from "../../lib/money";
import { PaymentMethod, Product, Rates } from "../../types";

const TYPES: Record<string, string> = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "application/pdf": "pdf" };
export default function Checkout() {
  const { items, currency, setCurrency, setQty, clear } = useCart();
  const { user, loginGoogle } = useAuth();
  const nav = useNavigate();
  const prods = useData(getProducts, [] as Product[]);
  const rates = useData(getRates, {} as Rates);
  const methods = useData(getPaymentMethods, [] as PaymentMethod[]);
  const link = useData(() => (user ? getMyLink(user.id) : Promise.resolve(null)), null as { mc_name: string } | null, [user?.id]);
  const [method, setMethod] = useState("");
  const [txn, setTxn] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [coupon, setCoupon] = useState("");
  const [pct, setPct] = useState<number | null>(null);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const lines = prods.data.filter((p) => items[p.id]).map((p) => ({ p, qty: items[p.id], ...unitPrice(p, currency, rates.data) }));
  const sub = lines.reduce((s, l) => s + l.now * l.qty, 0);
  const total = Math.round(sub * (1 - (pct ?? 0) / 100) * 100) / 100;
  const chosen = methods.data.find((m) => m.id === method);

  const applyCoupon = async () => {
    try { const v = await couponPercent(coupon.trim()); setPct(v); setMsg(v == null ? "Invalid or used-up coupon." : `Coupon applied: ${v}% off.`); } catch (e: any) { setMsg(e.message); }
  };
  const submit = async () => {
    setMsg("");
    if (!method) return setMsg("Choose a payment method.");
    if (!txn.trim()) return setMsg("Enter the transaction ID.");
    if (!file || !TYPES[file.type]) return setMsg("Upload your receipt as PNG, JPG, WEBP or PDF.");
    if (file.size > 5 * 1024 * 1024) return setMsg("Receipt must be under 5 MB.");
    setBusy(true);
    try {
      const path = `${user!.id}/${crypto.randomUUID()}.${TYPES[file.type]}`;
      const up = await db().storage.from("receipts").upload(path, file, { contentType: file.type });
      if (up.error) throw up.error;
      const id = await placeOrder(Object.entries(items).map(([k, qty]) => ({ id: k, qty })), currency, method, txn.trim(), path, pct != null ? coupon.trim() : null);
      notifyOrder(id);
      clear();
      nav("/account");
    } catch (e: any) { setMsg(e.message); } finally { setBusy(false); }
  };

  if (!lines.length) return <><h2>Cart</h2><p className="muted">Your cart is empty.</p><Link className="btn" to="/store">Go to store</Link></>;
  return (
    <>
      <h2>Checkout</h2>
      <div className="card">
        <label>Currency <select value={currency} onChange={(e) => { setCurrency(e.target.value); setPct(null); }}>{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</select></label>
        {lines.map((l) => (
          <div className="row" key={l.p.id}>
            <span>{l.p.name} × <input type="number" min={0} max={20} value={l.qty} onChange={(e) => setQty(l.p.id, Number(e.target.value))} style={{ width: 70, margin: 0 }} aria-label={"Quantity of " + l.p.name} /></span>
            <strong>{fmt(l.now * l.qty, currency)}</strong>
          </div>
        ))}
        <div className="row"><span>Coupon</span><span><input value={coupon} onChange={(e) => setCoupon(e.target.value)} style={{ width: 140, margin: 0 }} aria-label="Coupon code" /> <button className="btn alt" onClick={applyCoupon}>Apply</button></span></div>
        <div className="row"><strong>Total</strong><strong className="price">{fmt(total, currency)}</strong></div>
      </div>
      {!user && <div className="card"><p>Log in to pay.</p><button className="btn" onClick={() => loginGoogle()}>Continue with Google</button></div>}
      {user && !link.data && !link.loading && <div className="card"><p>Link your Minecraft account first so we know where to deliver.</p><Link className="btn" to="/account">Link account</Link></div>}
      {user && link.data && (
        <div className="card">
          <h3>Pay</h3>
          <p className="muted">Delivering to <strong>{link.data.mc_name}</strong>. You must be online in game when the order is approved.</p>
          <label htmlFor="pm">Payment method</label>
          <select id="pm" value={method} onChange={(e) => setMethod(e.target.value)}><option value="">Select…</option>{methods.data.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select>
          {chosen && <div className="card"><p>Send exactly <strong>{fmt(total, currency)}</strong> to:</p><p><code>{chosen.details}</code></p><p className="muted">{chosen.instructions}</p></div>}
          <label htmlFor="tx">Transaction ID</label>
          <input id="tx" value={txn} onChange={(e) => setTxn(e.target.value)} />
          <label htmlFor="rc">Payment receipt (screenshot or PDF)</label>
          <input id="rc" type="file" accept="image/png,image/jpeg,image/webp,application/pdf" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          <button className="btn" disabled={busy} onClick={submit}>{busy ? "Submitting…" : "Submit order"}</button>
        </div>
      )}
      <p className="muted" role="status">{msg}</p>
    </>
  );
}
