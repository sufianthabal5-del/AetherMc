import { useState } from "react";
import { Link } from "react-router-dom";
import { getTop } from "../../services/api";
import { useData } from "../../hooks/useData";
import { hours } from "../../lib/money";
import { PlayerRow } from "../../types";
const STATS: [string, string][] = [["balance", "Money"], ["kills", "Kills"], ["deaths", "Deaths"], ["mob_kills", "Mob kills"], ["playtime_seconds", "Playtime"]];
export default function Leaderboard() {
  const [col, setCol] = useState("balance");
  const { data, loading, error } = useData(() => getTop(col), [] as PlayerRow[], [col]);
  const val = (p: PlayerRow) => col === "playtime_seconds" ? hours(p.playtime_seconds) + " h" : Math.round((p as any)[col]).toLocaleString("en");
  return (
    <>
      <h2>Leaderboard</h2>
      <label htmlFor="st">Ranked by </label>
      <select id="st" value={col} onChange={(e) => setCol(e.target.value)}>{STATS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
      {error && <p className="muted">{error}</p>}
      <div className="card scroll">
        <table>
          <thead><tr><th>#</th><th>Player</th><th>{STATS.find((s) => s[0] === col)![1]}</th></tr></thead>
          <tbody>{data.map((p, i) => <tr key={p.uuid}><td>{i + 1}</td><td><Link to={"/player/" + p.name}>{p.name}</Link></td><td>{val(p)}</td></tr>)}</tbody>
        </table>
        {!loading && !data.length && <p className="muted">No player data synced from the server yet.</p>}
      </div>
    </>
  );
}
