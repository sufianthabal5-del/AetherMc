import { getGeneral } from "../../services/api";
import { useData } from "../../hooks/useData";
export default function Discord() {
  const { data } = useData(getGeneral, {} as { discord_invite?: string });
  return (
    <>
      <h2>Discord</h2>
      <div className="card">
        <p>Get announcements, find players, and open support tickets.</p>
        {data.discord_invite ? <a className="btn" href={data.discord_invite} target="_blank" rel="noopener noreferrer">Join our Discord</a> : <p className="muted">Invite link coming soon.</p>}
      </div>
    </>
  );
}
