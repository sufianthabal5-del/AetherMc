import { getRules } from "../../services/api";
import { useData } from "../../hooks/useData";
export default function Rules() {
  const { data, loading } = useData(getRules, [] as { id: string; body: string }[]);
  return <><h2>Rules</h2>{!loading && !data.length && <p className="muted">No rules added yet.</p>}<div className="card"><ul>{data.map((r) => <li key={r.id}>{r.body}</li>)}</ul></div></>;
}
