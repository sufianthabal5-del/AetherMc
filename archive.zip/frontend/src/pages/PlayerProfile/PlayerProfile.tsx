import { useParams } from "react-router-dom";
import { getPlayer } from "../../services/api";
import { useData } from "../../hooks/useData";
import PlayerCard from "../../components/minecraft/PlayerCard";
import { hours } from "../../lib/money";
import { PlayerRow } from "../../types";
export default function PlayerProfile() {
  const { name = "" } = useParams();
  const { data: p, loading } = useData(() => getPlayer(name), null as PlayerRow | null, [name]);
  if (loading) return <p className="muted">Loading…</p>;
  if (!p) return <><h2>{name}</h2><p className="muted">No stats for this player yet. Stats appear after they play on the server.</p></>;
  const stats: [string, string][] = [["Playtime", hours(p.playtime_seconds) + " h"], ["Kills", String(p.kills)], ["Deaths", String(p.deaths)], ["Mob kills", String(p.mob_kills)], ["Money", Math.round(p.balance).toLocaleString("en")]];
  return (
    <>
      <h2>{p.name}</h2>
      <div className="grid">{stats.map(([k, v]) => <div className="card" key={k}><div className="muted">{k}</div><div className="price">{v}</div></div>)}</div>
      <h3 style={{ marginTop: 24 }}>Player card</h3>
      <PlayerCard p={p} />
    </>
  );
}
