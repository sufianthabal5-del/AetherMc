import { getStaff } from "../../services/api";
import { useData } from "../../hooks/useData";
import { StaffMember } from "../../types";
export default function Staff() {
  const { data, loading } = useData(getStaff, [] as StaffMember[]);
  return (
    <>
      <h2>Staff</h2>
      {!loading && !data.length && <p className="muted">No staff listed yet.</p>}
      <div className="grid">
        {data.map((s) => <div className="card" key={s.id}><div className="av">{s.mc_name.charAt(0).toUpperCase()}</div><h3>{s.mc_name}</h3><div className="muted">{s.role}</div></div>)}
      </div>
    </>
  );
}
