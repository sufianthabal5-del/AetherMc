export const SITE = {
  name: "AetherMC",
  ip: "play.aethermc.fun",
  bedrockPort: 19133,
  floodgatePrefix: ".",
};
export const CURRENCIES = ["INR", "USD", "PKR", "BDT"];
export const NAV = [
  { to: "/", label: "Home" },
  { to: "/store", label: "Store" },
  { to: "/leaderboard", label: "Leaderboard" },
  { to: "/vote", label: "Vote" },
  { to: "/staff", label: "Staff" },
  { to: "/rules", label: "Rules" },
  { to: "/announcements", label: "News" },
  { to: "/discord", label: "Discord" },
];
