import CrudPage from "../layout/CrudPage";
export default function AdminSettings() {
  return <CrudPage {...({
  "title": "Site settings",
  "table": "site_settings",
  "orderBy": "key",
  "fields": [
    {
      "key": "key",
      "label": "Key",
      "type": "text"
    },
    {
      "key": "value",
      "label": "Value (JSON)",
      "type": "json"
    }
  ],
  "list": [
    "key",
    "value"
  ],
  "idKey": "key",
  "canCreate": true,
  "defaults": {},
  "hint": "rates = how many units of each currency equal 1 INR. general = {\"discord_invite\":\"https://discord.gg/...\"}."
})} />;
}
