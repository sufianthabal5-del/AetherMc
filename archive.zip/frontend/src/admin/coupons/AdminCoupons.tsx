import CrudPage from "../layout/CrudPage";
export default function AdminCoupons() {
  return <CrudPage {...({
  "title": "Coupons",
  "table": "coupons",
  "orderBy": "code",
  "fields": [
    {
      "key": "code",
      "label": "Code (UPPERCASE)",
      "type": "text"
    },
    {
      "key": "percent",
      "label": "Percent off",
      "type": "number"
    },
    {
      "key": "max_uses",
      "label": "Max uses (empty = unlimited)",
      "type": "nullnumber"
    },
    {
      "key": "active",
      "label": "Active",
      "type": "bool"
    }
  ],
  "list": [
    "code",
    "percent",
    "uses",
    "max_uses",
    "active"
  ],
  "idKey": "code",
  "canCreate": true,
  "defaults": {},
  "hint": "Store discounts and sale prices are set per product (Discount %). Coupons add a code on top."
})} />;
}
