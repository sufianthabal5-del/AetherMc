import CrudPage from "../layout/CrudPage";
export default function AdminAnnouncements() {
  return <CrudPage {...({
  "title": "Announcements",
  "table": "announcements",
  "orderBy": "created_at",
  "fields": [
    {
      "key": "title",
      "label": "Title",
      "type": "text"
    },
    {
      "key": "body",
      "label": "Body",
      "type": "textarea"
    },
    {
      "key": "published",
      "label": "Published",
      "type": "bool"
    }
  ],
  "list": [
    "title",
    "published",
    "created_at"
  ],
  "idKey": "id",
  "canCreate": true,
  "defaults": {},
  "hint": ""
})} />;
}
