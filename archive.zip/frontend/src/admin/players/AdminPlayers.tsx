import CrudPage from "../layout/CrudPage";
export default function AdminPlayers() {
  return <CrudPage {...({
  "title": "Players",
  "table": "players",
  "orderBy": "name",
  "fields": [
    {
      "key": "name",
      "label": "Name",
      "type": "text"
    },
    {
      "key": "kills",
      "label": "Kills",
      "type": "number"
    },
    {
      "key": "deaths",
      "label": "Deaths",
      "type": "number"
    },
    {
      "key": "mob_kills",
      "label": "Mob kills",
      "type": "number"
    },
    {
      "key": "playtime_seconds",
      "label": "Playtime (seconds)",
      "type": "number"
    },
    {
      "key": "balance",
      "label": "Money",
      "type": "number"
    }
  ],
  "list": [
    "name",
    "kills",
    "deaths",
    "mob_kills",
    "balance"
  ],
  "idKey": "uuid",
  "canCreate": false,
  "defaults": {},
  "hint": "Stats sync from the server every minute and overwrite manual edits."
})} />;
}
