import CrudPage from "../layout/CrudPage";
export default function AdminPaymentMethods() {
  return <CrudPage {...({
  "title": "Payment methods",
  "table": "payment_methods",
  "orderBy": "sort",
  "fields": [
    {
      "key": "name",
      "label": "Name",
      "type": "text"
    },
    {
      "key": "currency",
      "label": "Currencies it accepts (text)",
      "type": "text"
    },
    {
      "key": "details",
      "label": "Account number / IBAN / UPI ID shown to buyers",
      "type": "text"
    },
    {
      "key": "instructions",
      "label": "Instructions",
      "type": "textarea"
    },
    {
      "key": "active",
      "label": "Active",
      "type": "bool"
    },
    {
      "key": "sort",
      "label": "Sort order",
      "type": "number"
    }
  ],
  "list": [
    "name",
    "currency",
    "details",
    "active"
  ],
  "idKey": "id",
  "canCreate": true,
  "defaults": {},
  "hint": ""
})} />;
}
