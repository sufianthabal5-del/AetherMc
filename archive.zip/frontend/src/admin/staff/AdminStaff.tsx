import CrudPage from "../layout/CrudPage";
export default function AdminStaff() {
  return <CrudPage {...({
  "title": "Staff",
  "table": "staff_members",
  "orderBy": "sort",
  "fields": [
    {
      "key": "mc_name",
      "label": "Minecraft name",
      "type": "text"
    },
    {
      "key": "role",
      "label": "Role",
      "type": "text"
    },
    {
      "key": "sort",
      "label": "Sort order",
      "type": "number"
    },
    {
      "key": "active",
      "label": "Show on site",
      "type": "bool"
    }
  ],
  "list": [
    "mc_name",
    "role",
    "active"
  ],
  "idKey": "id",
  "canCreate": true,
  "defaults": {},
  "hint": ""
})} />;
}
