import CrudPage from "../layout/CrudPage";
export default function AdminProducts() {
  return <CrudPage {...({
  "title": "Products",
  "table": "products",
  "orderBy": "sort",
  "fields": [
    {
      "key": "name",
      "label": "Name",
      "type": "text"
    },
    {
      "key": "slug",
      "label": "Slug (unique, lowercase)",
      "type": "text"
    },
    {
      "key": "kind",
      "label": "Type",
      "type": "select",
      "options": [
        "rank",
        "kit",
        "coins",
        "lifesteal",
        "bundle"
      ]
    },
    {
      "key": "price",
      "label": "Base price in INR",
      "type": "number"
    },
    {
      "key": "prices",
      "label": "Fixed prices per currency, JSON e.g. {\"USD\":0.6} (optional)",
      "type": "json"
    },
    {
      "key": "discount_percent",
      "label": "Discount %",
      "type": "number"
    },
    {
      "key": "perks",
      "label": "Perks (one per line)",
      "type": "lines"
    },
    {
      "key": "commands",
      "label": "Delivery commands (one per line, use {player})",
      "type": "lines"
    },
    {
      "key": "active",
      "label": "Visible in store",
      "type": "bool"
    },
    {
      "key": "sort",
      "label": "Sort order",
      "type": "number"
    }
  ],
  "list": [
    "name",
    "kind",
    "price",
    "discount_percent",
    "active"
  ],
  "idKey": "id",
  "canCreate": true,
  "defaults": {},
  "hint": "Delivery commands run from the server console when an order is approved and the player is online."
})} />;
}
