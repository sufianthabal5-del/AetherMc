import CrudPage from "../layout/CrudPage";
export default function AdminVoting() {
  return <CrudPage {...({
  "title": "Vote sites",
  "table": "vote_sites",
  "orderBy": "sort",
  "fields": [
    {
      "key": "name",
      "label": "Name",
      "type": "text"
    },
    {
      "key": "url",
      "label": "Vote link",
      "type": "text"
    },
    {
      "key": "active",
      "label": "Active",
      "type": "bool"
    },
    {
      "key": "sort",
      "label": "Sort order",
      "type": "number"
    }
  ],
  "list": [
    "name",
    "url",
    "active"
  ],
  "idKey": "id",
  "canCreate": true,
  "defaults": {},
  "hint": ""
})} />;
}
