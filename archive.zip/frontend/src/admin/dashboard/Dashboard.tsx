import { Link } from "react-router-dom";
import { db } from "../../services/api";
import { useData } from "../../hooks/useData";
export default function Dashboard() {
  const { data } = useData(async () => {
    const c = async (t: string, f?: [string, string]) => { let q = db().from(t).select("*", { count: "exact", head: true }); if (f) q = q.eq(f[0], f[1]); return (await q).count ?? 0; };
    return { pending: await c("orders", ["status", "pending"]), orders: await c("orders"), players: await c("players"), products: await c("products") };
  }, { pending: 0, orders: 0, players: 0, products: 0 });
  return (
    <>
      <h2>Dashboard</h2>
      <div className="grid">
        <div className="card"><div className="muted">Orders waiting for review</div><div className="price">{data.pending}</div><Link className="btn" to="/admin/orders">Review</Link></div>
        <div className="card"><div className="muted">Total orders</div><div className="price">{data.orders}</div></div>
        <div className="card"><div className="muted">Players synced</div><div className="price">{data.players}</div></div>
        <div className="card"><div className="muted">Products</div><div className="price">{data.products}</div></div>
      </div>
    </>
  );
}
