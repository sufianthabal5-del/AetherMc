import CrudPage from "../layout/CrudPage";
export default function AdminRules() {
  return <CrudPage {...({
  "title": "Rules",
  "table": "rules",
  "orderBy": "sort",
  "fields": [
    {
      "key": "body",
      "label": "Rule",
      "type": "textarea"
    },
    {
      "key": "sort",
      "label": "Sort order",
      "type": "number"
    }
  ],
  "list": [
    "body",
    "sort"
  ],
  "idKey": "id",
  "canCreate": true,
  "defaults": {},
  "hint": ""
})} />;
}
