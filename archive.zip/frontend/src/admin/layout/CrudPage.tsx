import { FormEvent, useEffect, useState } from "react";
import { db } from "../../services/api";

export type Field = { key: string; label: string; type: "text" | "number" | "nullnumber" | "textarea" | "bool" | "select" | "lines" | "json"; options?: string[] };
interface Props { title: string; table: string; orderBy: string; fields: Field[]; list: string[]; idKey?: string; canCreate?: boolean; defaults?: Record<string, unknown>; hint?: string }

const toForm = (fields: Field[], src: any) => {
  const o: any = {};
  fields.forEach((f) => {
    const v = src?.[f.key];
    o[f.key] = f.type === "lines" ? (v ?? []).join("\n") : f.type === "json" ? JSON.stringify(v ?? {}) : f.type === "bool" ? v ?? true : f.type === "number" ? v ?? 0 : v ?? (f.type === "select" ? f.options![0] : "");
  });
  return o;
};
const toRow = (fields: Field[], form: any) => {
  const o: any = {};
  fields.forEach((f) => {
    const v = form[f.key];
    o[f.key] = f.type === "lines" ? String(v).split("\n").map((s) => s.trim()).filter(Boolean) : f.type === "json" ? JSON.parse(v || "{}") : f.type === "number" ? Number(v) : f.type === "nullnumber" ? (v === "" || v == null ? null : Number(v)) : v;
  });
  return o;
};
const show = (v: unknown) => (Array.isArray(v) ? v.join(", ") : typeof v === "boolean" ? (v ? "yes" : "no") : v && typeof v === "object" ? JSON.stringify(v) : String(v ?? ""));

export default function CrudPage({ title, table, orderBy, fields, list, idKey = "id", canCreate = true, defaults = {}, hint }: Props) {
  const [rows, setRows] = useState<any[]>([]);
  const [form, setForm] = useState<any>(() => toForm(fields, defaults));
  const [editing, setEditing] = useState<string | null>(null);
  const [msg, setMsg] = useState("");
  const load = async () => { const r = await db().from(table).select("*").order(orderBy); if (r.error) setMsg(r.error.message); else setRows(r.data ?? []); };
  useEffect(() => { load().catch((e) => setMsg(e.message)); }, []);
  const reset = () => { setEditing(null); setForm(toForm(fields, defaults)); };
  const save = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const row = toRow(fields, form);
      const r = editing ? await db().from(table).update(row).eq(idKey, editing) : await db().from(table).insert({ ...defaults, ...row });
      if (r.error) throw new Error(r.error.message);
      setMsg("Saved."); reset(); await load();
    } catch (err: any) { setMsg(err.message); }
  };
  const del = async (id: string) => {
    if (!confirm("Delete this item?")) return;
    const r = await db().from(table).delete().eq(idKey, id);
    setMsg(r.error ? r.error.message : "Deleted."); load();
  };
  return (
    <>
      <h2>{title}</h2>
      {hint && <p className="muted">{hint}</p>}
      {(canCreate || editing) && (
        <form className="card" onSubmit={save}>
          <h3>{editing ? "Edit" : "Add new"}</h3>
          {fields.map((f) => {
            const id = "f-" + f.key;
            const set = (v: unknown) => setForm({ ...form, [f.key]: v });
            return (
              <div key={f.key}>
                {f.type === "bool" ? <label><input type="checkbox" checked={!!form[f.key]} onChange={(e) => set(e.target.checked)} />{f.label}</label> : <label htmlFor={id}>{f.label}</label>}
                {f.type === "select" && <select id={id} value={form[f.key]} onChange={(e) => set(e.target.value)}>{f.options!.map((o) => <option key={o}>{o}</option>)}</select>}
                {(f.type === "textarea" || f.type === "lines" || f.type === "json") && <textarea id={id} value={form[f.key]} onChange={(e) => set(e.target.value)} />}
                {(f.type === "number" || f.type === "nullnumber") && <input id={id} type="number" step="any" value={form[f.key]} onChange={(e) => set(e.target.value)} />}
                {f.type === "text" && <input id={id} value={form[f.key]} onChange={(e) => set(e.target.value)} />}
              </div>
            );
          })}
          <button className="btn" type="submit">Save</button> {editing && <button type="button" className="btn alt" onClick={reset}>Cancel</button>}
        </form>
      )}
      <p className="muted" role="status">{msg}</p>
      <div className="card scroll">
        <table>
          <thead><tr>{list.map((k) => <th key={k}>{k}</th>)}<th /></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r[idKey]}>
                {list.map((k) => <td key={k}>{show(r[k])}</td>)}
                <td style={{ whiteSpace: "nowrap" }}><button className="btn alt" onClick={() => { setEditing(r[idKey]); setForm(toForm(fields, r)); window.scrollTo(0, 0); }}>Edit</button> <button className="btn alt" onClick={() => del(r[idKey])}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
        {!rows.length && <p className="muted">Nothing here yet.</p>}
      </div>
    </>
  );
}
