import { Navigate, NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
const LINKS = [["/admin", "Dashboard"], ["/admin/orders", "Orders"], ["/admin/products", "Products"], ["/admin/payment-methods", "Payments"], ["/admin/coupons", "Coupons"], ["/admin/players", "Players"], ["/admin/staff", "Staff"], ["/admin/rules", "Rules"], ["/admin/announcements", "News"], ["/admin/voting", "Vote sites"], ["/admin/settings", "Settings"]];
export default function AdminLayout() {
  const { user, admin, loading, logout } = useAuth();
  if (loading) return <main><p className="muted">Loading…</p></main>;
  if (!user) return <Navigate to="/login" replace />;
  if (!admin) return <main><h2>Not an admin</h2><p className="muted">{user.email} does not have admin access.</p></main>;
  return (
    <>
      <nav className="nav" aria-label="Admin">
        <NavLink to="/">← Site</NavLink>
        {LINKS.map(([to, l]) => <NavLink key={to} to={to} end={to === "/admin"}>{l}</NavLink>)}
        <button className="btn alt push" onClick={logout}>Log out</button>
      </nav>
      <main><Outlet /></main>
    </>
  );
}
