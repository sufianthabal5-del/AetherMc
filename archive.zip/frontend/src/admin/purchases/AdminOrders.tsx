import { useEffect, useState } from "react";
import { db } from "../../services/api";
import { fmt } from "../../lib/money";

export default function AdminOrders() {
  const [rows, setRows] = useState<any[]>([]);
  const [msg, setMsg] = useState("");
  const load = async () => {
    const r = await db().from("orders").select("*, order_items(name,qty,unit_price), payment_methods(name)").order("created_at", { ascending: false }).limit(100);
    if (r.error) setMsg(r.error.message); else setRows(r.data ?? []);
  };
  useEffect(() => { load().catch((e) => setMsg(e.message)); }, []);
  const receipt = async (path: string) => {
    const { data, error } = await db().storage.from("receipts").createSignedUrl(path, 300);
    if (error) setMsg(error.message); else window.open(data.signedUrl, "_blank", "noopener");
  };
  const approve = async (id: string) => {
    const r = await db().rpc("approve_order", { p_order: id });
    setMsg(r.error ? r.error.message : "Approved. Items are delivered when the player is online in game."); load();
  };
  const reject = async (id: string) => {
    const note = prompt("Reason for rejecting (shown to the customer):");
    if (note === null) return;
    const r = await db().rpc("reject_order", { p_order: id, p_note: note });
    setMsg(r.error ? r.error.message : "Rejected."); load();
  };
  return (
    <>
      <h2>Orders</h2>
      <p className="muted" role="status">{msg}</p>
      {!rows.length && <p className="muted">No orders yet.</p>}
      {rows.map((o) => (
        <div className="card" key={o.id}>
          <div className="row" style={{ borderTop: 0 }}><strong>{o.mc_name} · {fmt(Number(o.total), o.currency)}</strong><span className={"pill " + o.status}>{o.status}</span></div>
          <p>{o.order_items.map((i: any) => i.qty + "× " + i.name).join(", ")}</p>
          <p className="muted">{o.payment_methods?.name ?? "Method removed"} · Txn <code>{o.txn_ref}</code> · {new Date(o.created_at).toLocaleString()}</p>
          <button className="btn alt" onClick={() => receipt(o.receipt_path)}>View receipt</button>{" "}
          {o.status === "pending" && <><button className="btn" onClick={() => approve(o.id)}>Approve</button> <button className="btn alt" onClick={() => reject(o.id)}>Reject</button></>}
          {o.admin_note && <p className="muted">Note: {o.admin_note}</p>}
        </div>
      ))}
    </>
  );
}
