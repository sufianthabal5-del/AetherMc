import { Product, Rates } from "../types";
const r2 = (n: number) => Math.round(n * 100) / 100;
// Display price. The database recomputes this when an order is placed.
export function unitPrice(p: Product, cur: string, rates: Rates) {
  const base = p.prices?.[cur] ?? p.price * (rates[cur] ?? 1);
  return { now: r2(base * (1 - p.discount_percent / 100)), was: p.discount_percent > 0 ? r2(base) : null };
}
export const fmt = (n: number, cur: string) => new Intl.NumberFormat("en", { style: "currency", currency: cur }).format(n);
export const hours = (sec: number) => Math.round(sec / 3600);
