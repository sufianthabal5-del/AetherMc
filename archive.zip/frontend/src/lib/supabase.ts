import { createClient } from "@supabase/supabase-js";
const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
// Null when .env is missing; the site then shows mock data so it still runs.
export const supabase = url && key ? createClient(url, key) : null;
