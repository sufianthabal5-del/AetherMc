import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { AdminRole } from "../types";
import { supabase } from "../lib/supabase";

interface AuthUser { id: string; email: string }
interface Ctx { user: AuthUser | null; admin: AdminRole | null; loading: boolean; loginGoogle: () => Promise<string | null>; logout: () => void }
const AuthCtx = createContext<Ctx>({ user: null, admin: null, loading: false, loginGoogle: async () => "Not configured", logout: () => {} });
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [admin, setAdmin] = useState<AdminRole | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    const apply = async (s: { user: { id: string; email?: string } } | null) => {
      if (!s) { setUser(null); setAdmin(null); setLoading(false); return; }
      setUser({ id: s.user.id, email: s.user.email ?? "" });
      const { data } = await supabase!.from("admin_users").select("role").eq("user_id", s.user.id).maybeSingle();
      setAdmin((data?.role as AdminRole) ?? null);
      setLoading(false);
    };
    supabase.auth.getSession().then(({ data }) => apply(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { apply(s); });
    return () => sub.subscription.unsubscribe();
  }, []);
  // The admin check here only hides screens. Real protection is RLS in the database.
  const loginGoogle = async () => {
    if (!supabase) return "Supabase is not configured. Add your keys to .env.";
    const { error } = await supabase.auth.signInWithOAuth({ provider: "google", options: { redirectTo: window.location.origin + "/account" } });
    return error ? error.message : null;
  };
  const logout = () => { supabase?.auth.signOut(); setUser(null); setAdmin(null); };
  return <AuthCtx.Provider value={{ user, admin, loading, loginGoogle, logout }}>{children}</AuthCtx.Provider>;
}
