import { createContext, useContext, useEffect, useState, ReactNode } from "react";

interface Ctx { items: Record<string, number>; currency: string; count: number; add: (id: string) => void; setQty: (id: string, q: number) => void; clear: () => void; setCurrency: (c: string) => void }
const CartCtx = createContext<Ctx>({ items: {}, currency: "INR", count: 0, add: () => {}, setQty: () => {}, clear: () => {}, setCurrency: () => {} });
export const useCart = () => useContext(CartCtx);

const load = <T,>(k: string, d: T): T => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } };
const save = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage unavailable */ } };

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Record<string, number>>(() => load("aether-cart", {}));
  const [currency, setCurrency] = useState<string>(() => load("aether-cur", "INR"));
  useEffect(() => save("aether-cart", items), [items]);
  useEffect(() => save("aether-cur", currency), [currency]);
  const add = (id: string) => setItems((c) => ({ ...c, [id]: Math.min(20, (c[id] ?? 0) + 1) }));
  const setQty = (id: string, q: number) => setItems((c) => { const n = { ...c }; if (q <= 0) delete n[id]; else n[id] = Math.min(20, q); return n; });
  const count = Object.values(items).reduce((a, b) => a + b, 0);
  return <CartCtx.Provider value={{ items, currency, count, add, setQty, clear: () => setItems({}), setCurrency }}>{children}</CartCtx.Provider>;
}
