export type Kind = "rank" | "kit" | "coins" | "lifesteal" | "bundle";
export type Rates = Record<string, number>;
export type AdminRole = "owner" | "admin" | "mod";
export interface Product { id: string; name: string; slug: string; kind: Kind; price: number; prices: Record<string, number>; discount_percent: number; perks: string[] }
export interface StaffMember { id: string; mc_name: string; role: string }
export interface VoteSite { id: string; name: string; url: string }
export interface PlayerRow { uuid: string; name: string; playtime_seconds: number; kills: number; deaths: number; mob_kills: number; balance: number; last_seen: string | null }
export interface PaymentMethod { id: string; name: string; currency: string; details: string; instructions: string }
export interface Announcement { id: string; title: string; body: string; created_at: string }
export interface ServerStatus { players: number; max_players: number; version: string | null; tps: number | null; updated_at: string }
export interface OrderRow { id: string; mc_name: string; currency: string; subtotal: number; discount: number; total: number; status: string; txn_ref: string; receipt_path: string; admin_note: string | null; created_at: string; order_items: { name: string; qty: number; unit_price: number }[] }
