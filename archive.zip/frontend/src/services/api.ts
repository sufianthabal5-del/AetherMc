import { supabase } from "../lib/supabase";
import { Announcement, OrderRow, PaymentMethod, PlayerRow, Product, Rates, ServerStatus, StaffMember, VoteSite } from "../types";

export function db() {
  if (!supabase) throw new Error("The site is not connected to Supabase yet. Add your keys to frontend/.env.");
  return supabase;
}
const ok = <T,>(r: { data: T | null; error: { message: string } | null }): T => {
  if (r.error) throw new Error(r.error.message);
  return r.data as T;
};

export const getProducts = async () => ok<Product[]>(await db().from("products").select("id,name,slug,kind,price,prices,discount_percent,perks").eq("active", true).order("sort"));
export const getRates = async () => (ok<any>(await db().from("site_settings").select("value").eq("key", "rates").single()).value ?? {}) as Rates;
export const getGeneral = async () => (ok<any>(await db().from("site_settings").select("value").eq("key", "general").maybeSingle())?.value ?? {}) as { discord_invite?: string };
export const getStaff = async () => ok<StaffMember[]>(await db().from("staff_members").select("id,mc_name,role").eq("active", true).order("sort"));
export const getRules = async () => ok<{ id: string; body: string }[]>(await db().from("rules").select("id,body").order("sort"));
export const getVoteSites = async () => ok<VoteSite[]>(await db().from("vote_sites").select("id,name,url").eq("active", true).order("sort"));
export const getAnnouncements = async (n = 20) => ok<Announcement[]>(await db().from("announcements").select("id,title,body,created_at").eq("published", true).order("created_at", { ascending: false }).limit(n));
export const getPaymentMethods = async () => ok<PaymentMethod[]>(await db().from("payment_methods").select("id,name,currency,details,instructions").eq("active", true).order("sort"));
export const getStatus = async () => ok<ServerStatus | null>(await db().from("server_status").select("*").maybeSingle());
export const getTop = async (col: string) => ok<PlayerRow[]>(await db().from("players").select("*").order(col, { ascending: false }).limit(25));
export const getPlayer = async (name: string) => ok<PlayerRow | null>(await db().from("players").select("*").eq("name", name).maybeSingle());
export const getMyLink = async (uid: string) => ok<{ mc_name: string } | null>(await db().from("mc_links").select("mc_name").eq("user_id", uid).maybeSingle());
export const getMyOrders = async (uid: string) => ok<OrderRow[]>(await db().from("orders").select("id,mc_name,currency,subtotal,discount,total,status,txn_ref,receipt_path,admin_note,created_at,order_items(name,qty,unit_price)").eq("user_id", uid).order("created_at", { ascending: false }));
export const createLinkCode = async () => ok<string>(await db().rpc("create_link_code"));
export const couponPercent = async (code: string) => ok<number | null>(await db().rpc("coupon_percent", { p_code: code }));
export async function placeOrder(items: { id: string; qty: number }[], currency: string, method: string, txn: string, receipt: string, coupon: string | null) {
  return ok<string>(await db().rpc("place_order", { p_items: items, p_currency: currency, p_method: method, p_txn: txn, p_receipt: receipt, p_coupon: coupon }));
}
export async function notifyOrder(orderId: string) {
  try {
    const { data } = await db().auth.getSession();
    await fetch("/.netlify/functions/notify-order", { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + (data.session?.access_token ?? "") }, body: JSON.stringify({ order_id: orderId }) });
  } catch { /* Discord notice is best effort */ }
}
