import { Routes, Route } from "react-router-dom";
import Layout from "../components/layout/Layout";
import Home from "../pages/Home/Home";
import Store from "../pages/Store/Store";
import Checkout from "../pages/Checkout/Checkout";
import Account from "../pages/Account/Account";
import Vote from "../pages/Vote/Vote";
import Staff from "../pages/Staff/Staff";
import Rules from "../pages/Rules/Rules";
import Discord from "../pages/Discord/Discord";
import Leaderboard from "../pages/Leaderboard/Leaderboard";
import PlayerProfile from "../pages/PlayerProfile/PlayerProfile";
import Announcements from "../pages/Announcements/Announcements";
import Login from "../pages/Login/Login";
import NotFound from "../pages/NotFound/NotFound";
import AdminLayout from "../admin/layout/AdminLayout";
import Dashboard from "../admin/dashboard/Dashboard";
import AdminOrders from "../admin/purchases/AdminOrders";
import AdminProducts from "../admin/products/AdminProducts";
import AdminPaymentMethods from "../admin/payment-methods/AdminPaymentMethods";
import AdminCoupons from "../admin/coupons/AdminCoupons";
import AdminPlayers from "../admin/players/AdminPlayers";
import AdminStaff from "../admin/staff/AdminStaff";
import AdminRules from "../admin/rules/AdminRules";
import AdminAnnouncements from "../admin/announcements/AdminAnnouncements";
import AdminVoting from "../admin/voting/AdminVoting";
import AdminSettings from "../admin/website-settings/AdminSettings";

export function AppRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="store" element={<Store />} />
        <Route path="checkout" element={<Checkout />} />
        <Route path="account" element={<Account />} />
        <Route path="vote" element={<Vote />} />
        <Route path="staff" element={<Staff />} />
        <Route path="rules" element={<Rules />} />
        <Route path="discord" element={<Discord />} />
        <Route path="leaderboard" element={<Leaderboard />} />
        <Route path="player/:name" element={<PlayerProfile />} />
        <Route path="announcements" element={<Announcements />} />
        <Route path="login" element={<Login />} />
        <Route path="*" element={<NotFound />} />
      </Route>
      <Route path="admin" element={<AdminLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="orders" element={<AdminOrders />} />
        <Route path="products" element={<AdminProducts />} />
        <Route path="payment-methods" element={<AdminPaymentMethods />} />
        <Route path="coupons" element={<AdminCoupons />} />
        <Route path="players" element={<AdminPlayers />} />
        <Route path="staff" element={<AdminStaff />} />
        <Route path="rules" element={<AdminRules />} />
        <Route path="announcements" element={<AdminAnnouncements />} />
        <Route path="voting" element={<AdminVoting />} />
        <Route path="settings" element={<AdminSettings />} />
      </Route>
    </Routes>
  );
}
