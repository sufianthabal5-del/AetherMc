# AetherMC frontend

React + Vite + TypeScript.

## Run
```
npm install
npm run dev
```
Build: `npm run build` (output in `dist`). Netlify config is included (SPA redirect).

## Edit your info
`src/constants/site.ts` holds the IP, Bedrock port, Discord invite, and store link.
Mock data lives in `src/services/api.ts`; phase 2 swaps it for Supabase queries.

## Status
Done: all public pages, layout, theme, admin shell with staff form (local only).
Next: Supabase auth + database, then products/purchases/voting admin, then the Minecraft bridge plugin.
The admin route guard here is client-side only; real security comes from Supabase row-level security.
