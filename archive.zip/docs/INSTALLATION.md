# Installation

## 1. Database (Supabase)
SQL editor, run in order: `supabase/schema.sql`, `supabase/migrations/0002_store.sql`, `supabase/seed.sql`.

## 2. Google login
1. Google Cloud Console > APIs & Services > Credentials > Create credentials > OAuth client ID > Web application.
2. Authorized redirect URI: `https://<your-project-ref>.supabase.co/auth/v1/callback`
3. Copy the Client ID and Client Secret.
4. Supabase > Authentication > Providers > Google: enable, paste both, save.
5. Supabase > Authentication > URL Configuration: set Site URL to your site, and add Redirect URLs `https://your-site/**` and `http://localhost:5173/**`.

## 3. Make yourself owner
Open the site, log in with Google once, then run in the SQL editor (your Google email):
```sql
insert into public.admin_users (user_id, role)
select id, 'owner' from auth.users where email = 'you@gmail.com';
```
Reload: an "Admin" link appears in the menu.

## 4. Deploy (Netlify)
Import the repo. Set the environment variables listed in `.env.example`. Generate the plugin key with `openssl rand -hex 32`.

## 5. Minecraft plugin
1. `cd minecraft-bridge && mvn package`, copy `target/AetherMCBridge-1.0.0.jar` into `plugins/`.
2. Server needs Vault and EssentialsX (NuVotifier optional).
3. Start once, then edit `plugins/AetherMCBridge/config.yml`: `api-url` = `https://your-site/.netlify/functions`, `api-key` = your PLUGIN_API_KEY. Restart.

## 6. Finish setup in Admin
- Settings: `general` = `{"discord_invite":"https://discord.gg/..."}`; check `rates`.
- Products: replace the placeholder delivery commands with your real LuckPerms groups and Essentials kit names.
- Payment methods, staff, rules, vote sites, announcements.

## 7. Test
Link account (`/link CODE` in game), place a small order, approve it in Admin > Orders, confirm the item arrives, check Leaderboard and the status dot on Home.
