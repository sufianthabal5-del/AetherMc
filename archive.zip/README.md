# AetherMC

One project: website + admin panel (`frontend`), Netlify functions (`backend`), database (`supabase`), server plugin (`minecraft-bridge`).

Start with `docs/INSTALLATION.md`.

Not included yet: a Discord bot with slash commands (`discord-bot/` is empty). Discord is integrated through your invite link (Admin > Settings) and order notices via webhook.
