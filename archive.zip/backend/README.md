# Backend

Netlify Functions (TypeScript), deployed with the site. Endpoints live at `/.netlify/functions/<name>`:
- `plugin-sync`, `plugin-deliveries`, `plugin-link`, `plugin-vote`: called by the Minecraft plugin with the `x-api-key` header (`PLUGIN_API_KEY`).
- `notify-order`: called by the website after checkout; posts to your Discord webhook.

Business rules (prices, approvals, delivery queue) live in the database functions in `supabase/migrations/0002_store.sql`.
