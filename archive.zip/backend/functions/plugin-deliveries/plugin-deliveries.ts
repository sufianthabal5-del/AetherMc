import { sb, json, pluginAuthed } from "../../services/db";

// GET: pending delivery commands. POST {done:[ids], failed:[ids]}: acknowledge them.
export default async (req: Request) => {
  if (!pluginAuthed(req)) return json({ error: "Unauthorized" }, 401);
  if (req.method === "GET") {
    const { data, error } = await sb.from("deliveries").select("id,mc_name,command").eq("status", "pending").order("created_at").limit(50);
    return error ? json({ error: error.message }, 500) : json(data);
  }
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  let b: any;
  try { b = await req.json(); } catch { return json({ error: "Bad JSON" }, 400); }
  const ids = (x: unknown) => (Array.isArray(x) ? x.map(String).slice(0, 100) : []);
  const done = ids(b.done), failed = ids(b.failed);
  const now = new Date().toISOString();
  if (done.length) await sb.from("deliveries").update({ status: "done", done_at: now }).in("id", done).eq("status", "pending");
  if (failed.length) await sb.from("deliveries").update({ status: "failed", done_at: now }).in("id", failed).eq("status", "pending");
  if (done.length) {
    const { data } = await sb.from("deliveries").select("order_id").in("id", done);
    for (const oid of new Set((data ?? []).map((d: any) => d.order_id))) {
      const { count } = await sb.from("deliveries").select("id", { count: "exact", head: true }).eq("order_id", oid).neq("status", "done");
      if (count === 0) await sb.from("orders").update({ status: "delivered" }).eq("id", oid).eq("status", "approved");
    }
  }
  return json({ ok: true });
};
