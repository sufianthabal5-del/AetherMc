import { sb, json, pluginAuthed, NAME_RE } from "../../services/db";

export default async (req: Request) => {
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  if (!pluginAuthed(req)) return json({ error: "Unauthorized" }, 401);
  let b: any;
  try { b = await req.json(); } catch { return json({ error: "Bad JSON" }, 400); }
  if (!NAME_RE.test(String(b.name))) return json({ error: "Invalid name" }, 400);
  const { error } = await sb.from("vote_log").insert({ player_name: b.name, site: String(b.site ?? "").slice(0, 80) });
  return error ? json({ error: error.message }, 500) : json({ ok: true });
};
