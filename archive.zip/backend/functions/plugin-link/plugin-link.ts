import { sb, json, pluginAuthed, NAME_RE, UUID_RE } from "../../services/db";

// Player ran /link CODE in game.
export default async (req: Request) => {
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  if (!pluginAuthed(req)) return json({ error: "Unauthorized" }, 401);
  let b: any;
  try { b = await req.json(); } catch { return json({ error: "Bad JSON" }, 400); }
  const code = String(b.code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
  if (!code || !UUID_RE.test(String(b.uuid)) || !NAME_RE.test(String(b.name))) return json({ error: "Invalid request" }, 400);
  const { data: row } = await sb.from("link_codes").select("user_id").eq("code", code).gt("expires_at", new Date().toISOString()).maybeSingle();
  if (!row) return json({ error: "Invalid or expired code" }, 400);
  const { error } = await sb.from("mc_links").upsert({ user_id: row.user_id, mc_uuid: b.uuid, mc_name: b.name, linked_at: new Date().toISOString() }, { onConflict: "user_id" });
  if (error) return json({ error: error.code === "23505" ? "This Minecraft account is already linked to another website account" : error.message }, 409);
  await sb.from("link_codes").delete().eq("code", code);
  return json({ ok: true });
};
