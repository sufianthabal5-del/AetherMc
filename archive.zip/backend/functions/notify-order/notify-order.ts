import { sb, json } from "../../services/db";

// Called by the website after a customer places an order. Posts to a Discord webhook.
export default async (req: Request) => {
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  const token = (req.headers.get("authorization") ?? "").replace(/^Bearer /i, "");
  const { data: u } = await sb.auth.getUser(token);
  if (!u?.user) return json({ error: "Unauthorized" }, 401);
  let b: any;
  try { b = await req.json(); } catch { return json({ error: "Bad JSON" }, 400); }
  const { data: o } = await sb.from("orders").select("id,mc_name,total,currency,txn_ref,order_items(name,qty)").eq("id", String(b.order_id)).eq("user_id", u.user.id).maybeSingle();
  if (!o) return json({ error: "Not found" }, 404);
  const hook = process.env.DISCORD_WEBHOOK_URL;
  if (hook) {
    const items = (o.order_items as any[]).map((i) => i.qty + "x " + i.name).join(", ");
    await fetch(hook, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ content: "New order from " + o.mc_name + ": " + o.total + " " + o.currency + " (" + items + "). Txn: " + o.txn_ref + ". Review it in the admin panel.", allowed_mentions: { parse: [] } }) }).catch(() => {});
  }
  return json({ ok: true });
};
