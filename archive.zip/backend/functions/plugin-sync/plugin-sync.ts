import { sb, json, pluginAuthed, NAME_RE, UUID_RE, num } from "../../services/db";

// Minecraft plugin -> website: server status + online player stats.
export default async (req: Request) => {
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  if (!pluginAuthed(req)) return json({ error: "Unauthorized" }, 401);
  let b: any;
  try { b = await req.json(); } catch { return json({ error: "Bad JSON" }, 400); }
  const s = b.server ?? {};
  const st = await sb.from("server_status").upsert({ id: 1, players: num(s.players), max_players: num(s.max_players), version: String(s.version ?? "").slice(0, 40), tps: s.tps == null ? null : num(s.tps), updated_at: new Date().toISOString() });
  if (st.error) return json({ error: st.error.message }, 500);
  const rows = (Array.isArray(b.players) ? b.players : []).slice(0, 500)
    .filter((p: any) => UUID_RE.test(String(p.uuid)) && NAME_RE.test(String(p.name)))
    .map((p: any) => ({ uuid: p.uuid, name: p.name, playtime_seconds: Math.max(0, Math.floor(num(p.playtime_seconds))), kills: Math.max(0, Math.floor(num(p.kills))), deaths: Math.max(0, Math.floor(num(p.deaths))), mob_kills: Math.max(0, Math.floor(num(p.mob_kills))), balance: num(p.balance), last_seen: new Date().toISOString(), updated_at: new Date().toISOString() }));
  if (rows.length) {
    const { error } = await sb.from("players").upsert(rows, { onConflict: "uuid" });
    if (error) return json({ error: error.message }, 500);
  }
  return json({ ok: true, players: rows.length });
};
