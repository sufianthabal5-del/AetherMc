import { createClient } from "@supabase/supabase-js";
import { timingSafeEqual } from "node:crypto";

export const sb = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } });
export const json = (d: unknown, status = 200) => new Response(JSON.stringify(d), { status, headers: { "content-type": "application/json" } });

export function pluginAuthed(req: Request): boolean {
  const key = process.env.PLUGIN_API_KEY;
  const got = req.headers.get("x-api-key") ?? "";
  if (!key || key.length < 24) return false;
  const a = Buffer.from(got), b = Buffer.from(key);
  return a.length === b.length && timingSafeEqual(a, b);
}
export const NAME_RE = /^[A-Za-z0-9_.]{1,20}$/;
export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const num = (v: unknown) => (Number.isFinite(Number(v)) ? Number(v) : 0);
