-- Real starting data from your price list. Edit everything later in the admin panel.
-- Delivery commands below are PLACEHOLDERS: set your real LuckPerms group names and Essentials kit names in Admin > Products.
insert into public.site_settings (key, value) values
 ('rates', '{"INR":1,"USD":0.0115,"PKR":3.3,"BDT":1.4}'),
 ('general', '{"discord_invite":""}')
on conflict (key) do nothing;

insert into public.products (name, slug, kind, price, prices, discount_percent, perks, commands, sort) values
 ('Crystal Kit','crystal-kit','kit',80,'{}',0,'{}',array['kit crystal {player}'],1),
 ('Mace Kit','mace-kit','kit',100,'{}',0,'{}',array['kit mace {player}'],2),
 ('Spear + Mace + Elytra Kit','spear-mace-elytra-kit','kit',150,'{}',0,'{}',array['kit spearmaceelytra {player}'],3),
 ('Aether+','aether-plus','rank',999,'{}',30,'{}',array['lp user {player} parent add aether'],10),
 ('Deadliest','deadliest','rank',399,'{}',0,'{}',array['lp user {player} parent add deadliest'],11),
 ('Master','master','rank',99,'{}',0,'{}',array['lp user {player} parent add master'],12),
 ('Ocean','ocean','rank',599,'{}',0,'{}',array['lp user {player} parent add ocean'],13),
 ('Turtle','turtle','rank',799,'{}',15,'{}',array['lp user {player} parent add turtle'],14),
 ('700 Coins','coins-700','coins',50,'{"USD":0.60}',0,'{}',array['eco give {player} 700'],20),
 ('1,500 Coins','coins-1500','coins',100,'{"USD":1.20}',0,'{}',array['eco give {player} 1500'],21),
 ('2,800 Coins','coins-2800','coins',200,'{"USD":2.50}',0,'{}',array['eco give {player} 2800'],22),
 ('5,660 Coins','coins-5660','coins',375,'{"USD":4.60}',0,'{}',array['eco give {player} 5660'],23),
 ('7,800 Coins','coins-7800','coins',530,'{"USD":6.50}',0,'{}',array['eco give {player} 7800'],24),
 ('15,600 Coins','coins-15600','coins',899,'{"USD":11.00}',0,'{}',array['eco give {player} 15600'],25);

insert into public.payment_methods (name, currency, details, instructions, sort) values
 ('SadaPay (Pakistan)','PKR','03436692077','Send the exact total, then upload the payment screenshot and enter the transaction ID.',1),
 ('International bank transfer (IBAN)','USD / INR / BDT','PK97SADA0000003436692078','Send the exact total, then upload the payment screenshot and enter the transaction ID.',2);
