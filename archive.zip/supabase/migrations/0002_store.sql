-- Run after schema.sql. Store, orders, receipts, account linking, server sync.
alter table public.players add column if not exists mob_kills int not null default 0;
alter table public.products add column if not exists kind text not null default 'rank' check (kind in ('rank','kit','coins','lifesteal','bundle'));
alter table public.products add column if not exists prices jsonb not null default '{}';
alter table public.products add column if not exists discount_percent numeric not null default 0 check (discount_percent between 0 and 100);
alter table public.products add column if not exists commands text[] not null default '{}';

create table public.server_status (id int primary key default 1 check (id = 1), players int not null default 0, max_players int not null default 0, version text, tps numeric, updated_at timestamptz not null default now());
create table public.mc_links (user_id uuid primary key references auth.users(id) on delete cascade, mc_uuid uuid unique not null, mc_name text not null, linked_at timestamptz not null default now());
create table public.link_codes (code text primary key, user_id uuid not null references auth.users(id) on delete cascade, expires_at timestamptz not null);
create table public.payment_methods (id uuid primary key default gen_random_uuid(), name text not null, currency text not null default '', details text not null, instructions text not null default '', active boolean not null default true, sort int not null default 0);
create table public.coupons (code text primary key, percent numeric not null check (percent between 0 and 100), active boolean not null default true, uses int not null default 0, max_uses int);
create table public.orders (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id),
  mc_uuid uuid not null, mc_name text not null, currency text not null,
  subtotal numeric not null default 0, discount numeric not null default 0, total numeric not null default 0,
  payment_method_id uuid references public.payment_methods(id), txn_ref text not null, receipt_path text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected','delivered')),
  admin_note text, created_at timestamptz not null default now(), reviewed_at timestamptz
);
create unique index orders_txn_unique on public.orders (lower(txn_ref)) where status <> 'rejected';
create table public.order_items (id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade, product_id uuid references public.products(id) on delete set null, name text not null, qty int not null, unit_price numeric not null);
create table public.deliveries (id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade, mc_name text not null, command text not null, status text not null default 'pending' check (status in ('pending','done','failed')), created_at timestamptz not null default now(), done_at timestamptz);

alter table public.server_status enable row level security;
alter table public.mc_links enable row level security;
alter table public.link_codes enable row level security;
alter table public.payment_methods enable row level security;
alter table public.coupons enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.deliveries enable row level security;

create policy "public read" on public.server_status for select using (true);
create policy "own link" on public.mc_links for select using (user_id = auth.uid() or public.is_admin());
create policy "public read" on public.payment_methods for select using (active);
create policy "admin all" on public.payment_methods for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all" on public.coupons for all using (public.is_admin()) with check (public.is_admin());
create policy "own orders" on public.orders for select using (user_id = auth.uid() or public.is_admin());
create policy "own items" on public.order_items for select using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));
create policy "admin read" on public.deliveries for select using (public.is_admin());
-- link_codes has no policy on purpose: only the functions below and the service role touch it.

create or replace function public.create_link_code() returns text language plpgsql security definer set search_path = public as $$
declare c text;
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  delete from link_codes where user_id = auth.uid() or expires_at < now();
  c := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
  insert into link_codes (code, user_id, expires_at) values (c, auth.uid(), now() + interval '10 minutes');
  return c;
end $$;

create or replace function public.coupon_percent(p_code text) returns numeric language sql security definer stable set search_path = public as $$
  select percent from coupons where code = upper(trim(p_code)) and active and (max_uses is null or uses < max_uses);
$$;

-- Prices are computed here, never trusted from the browser.
create or replace function public.place_order(p_items jsonb, p_currency text, p_method uuid, p_txn text, p_receipt text, p_coupon text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); lnk record; rates jsonb; rate numeric; oid uuid; sub numeric := 0; r record; line numeric; pct numeric; tot numeric;
begin
  if uid is null then raise exception 'Login required'; end if;
  select * into lnk from mc_links where user_id = uid;
  if not found then raise exception 'Link your Minecraft account first'; end if;
  select value into rates from site_settings where key = 'rates';
  rate := (rates ->> p_currency)::numeric;
  if rate is null then raise exception 'Unsupported currency'; end if;
  if p_receipt is null or p_receipt not like uid::text || '/%' then raise exception 'Receipt required'; end if;
  if coalesce(trim(p_txn), '') = '' then raise exception 'Transaction ID required'; end if;
  if not exists (select 1 from payment_methods where id = p_method and active) then raise exception 'Choose a payment method'; end if;
  insert into orders (user_id, mc_uuid, mc_name, currency, payment_method_id, txn_ref, receipt_path)
    values (uid, lnk.mc_uuid, lnk.mc_name, p_currency, p_method, trim(p_txn), p_receipt) returning id into oid;
  for r in select p.id, p.name, p.price, p.prices, p.discount_percent, greatest(least((i ->> 'qty')::int, 20), 1) as qty
           from jsonb_array_elements(p_items) i join products p on p.id = (i ->> 'id')::uuid and p.active loop
    line := round(coalesce((r.prices ->> p_currency)::numeric, r.price * rate) * (1 - r.discount_percent / 100), 2);
    insert into order_items (order_id, product_id, name, qty, unit_price) values (oid, r.id, r.name, r.qty, line);
    sub := sub + line * r.qty;
  end loop;
  if sub = 0 then raise exception 'Cart is empty'; end if;
  if coalesce(p_coupon, '') <> '' then
    update coupons set uses = uses + 1 where code = upper(trim(p_coupon)) and active and (max_uses is null or uses < max_uses) returning percent into pct;
  end if;
  tot := round(sub * (1 - coalesce(pct, 0) / 100), 2);
  update orders set subtotal = sub, discount = sub - tot, total = tot where id = oid;
  return oid;
end $$;

create or replace function public.approve_order(p_order uuid) returns void language plpgsql security definer set search_path = public as $$
declare o record; it record; cmd text; n int;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  select * into o from orders where id = p_order for update;
  if not found or o.status <> 'pending' then raise exception 'Order is not pending'; end if;
  for it in select oi.qty, p.commands from order_items oi join products p on p.id = oi.product_id where oi.order_id = p_order loop
    for n in 1..it.qty loop
      foreach cmd in array it.commands loop
        insert into deliveries (order_id, mc_name, command) values (p_order, o.mc_name, replace(cmd, '{player}', o.mc_name));
      end loop;
    end loop;
  end loop;
  update orders set status = 'approved', reviewed_at = now() where id = p_order;
  insert into activity_logs (actor, action, details) values (auth.uid(), 'order_approved', jsonb_build_object('order', p_order));
end $$;

create or replace function public.reject_order(p_order uuid, p_note text) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  update orders set status = 'rejected', admin_note = p_note, reviewed_at = now() where id = p_order and status = 'pending';
  if not found then raise exception 'Order is not pending'; end if;
  insert into activity_logs (actor, action, details) values (auth.uid(), 'order_rejected', jsonb_build_object('order', p_order));
end $$;

revoke execute on function public.create_link_code(), public.coupon_percent(text), public.place_order(jsonb,text,uuid,text,text,text), public.approve_order(uuid), public.reject_order(uuid,text) from public, anon;
grant execute on function public.create_link_code(), public.coupon_percent(text), public.place_order(jsonb,text,uuid,text,text,text), public.approve_order(uuid), public.reject_order(uuid,text) to authenticated;

-- Private receipt storage: users upload into their own folder, admins can read all.
insert into storage.buckets (id, name, public) values ('receipts', 'receipts', false) on conflict do nothing;
create policy "upload own receipt" on storage.objects for insert to authenticated with check (bucket_id = 'receipts' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "read own or admin receipt" on storage.objects for select to authenticated using (bucket_id = 'receipts' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
