# Supabase setup

Run in the SQL editor, in this order:
1. `schema.sql`
2. `migrations/0002_store.sql`
3. `seed.sql`

Then see `docs/INSTALLATION.md` for Google login and making yourself owner.
