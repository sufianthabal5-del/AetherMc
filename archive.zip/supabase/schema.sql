-- AetherMC database. Run this first in the Supabase SQL editor, then seed.sql.
create extension if not exists pgcrypto;

create table public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'mod' check (role in ('owner','admin','mod')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.admin_users where user_id = auth.uid() and role in ('owner','admin'));
$$;

create table public.site_settings (key text primary key, value jsonb not null default '{}');
create table public.categories (id uuid primary key default gen_random_uuid(), name text not null, sort int not null default 0);
create table public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.categories(id) on delete set null,
  name text not null, slug text unique not null,
  price numeric(10,2) not null check (price >= 0),
  description text not null default '', perks text[] not null default '{}',
  tebex_package_id text, active boolean not null default true, sort int not null default 0
);
create table public.staff_members (id uuid primary key default gen_random_uuid(), mc_name text not null, role text not null, sort int not null default 0, active boolean not null default true);
create table public.rules (id uuid primary key default gen_random_uuid(), body text not null, sort int not null default 0);
create table public.announcements (id uuid primary key default gen_random_uuid(), title text not null, body text not null, published boolean not null default false, created_at timestamptz not null default now());
create table public.vote_sites (id uuid primary key default gen_random_uuid(), name text not null, url text not null, active boolean not null default true, sort int not null default 0);
create table public.players (
  uuid uuid primary key, name text not null,
  playtime_seconds bigint not null default 0, kills int not null default 0, deaths int not null default 0,
  balance numeric not null default 0, points int not null default 0, rank text,
  last_seen timestamptz, updated_at timestamptz not null default now()
);
create table public.vote_log (id bigserial primary key, player_name text not null, site text not null, voted_at timestamptz not null default now());
create table public.purchases (
  id uuid primary key default gen_random_uuid(), tebex_txn_id text unique not null,
  player_name text not null, package_name text not null, amount numeric(10,2) not null,
  currency text not null default 'USD', status text not null default 'complete', created_at timestamptz not null default now()
);
create table public.activity_logs (id bigserial primary key, actor uuid, action text not null, details jsonb, created_at timestamptz not null default now());

-- Row Level Security: this is what actually protects your data.
alter table public.admin_users enable row level security;
alter table public.site_settings enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.staff_members enable row level security;
alter table public.rules enable row level security;
alter table public.announcements enable row level security;
alter table public.vote_sites enable row level security;
alter table public.players enable row level security;
alter table public.vote_log enable row level security;
alter table public.purchases enable row level security;
alter table public.activity_logs enable row level security;

-- Anyone can read public content.
create policy "public read" on public.site_settings for select using (true);
create policy "public read" on public.categories for select using (true);
create policy "public read" on public.products for select using (active);
create policy "public read" on public.staff_members for select using (active);
create policy "public read" on public.rules for select using (true);
create policy "public read" on public.announcements for select using (published);
create policy "public read" on public.vote_sites for select using (active);
create policy "public read" on public.players for select using (true);

-- Admins can do everything on content tables.
create policy "admin all" on public.site_settings for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all" on public.categories for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all" on public.products for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all" on public.staff_members for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all" on public.rules for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all" on public.announcements for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all" on public.vote_sites for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all" on public.players for all using (public.is_admin()) with check (public.is_admin());

-- Private tables: admins read only. Writes come from server functions using the service role key.
create policy "admin read" on public.vote_log for select using (public.is_admin());
create policy "admin read" on public.purchases for select using (public.is_admin());
create policy "admin read" on public.activity_logs for select using (public.is_admin());
create policy "read own role" on public.admin_users for select using (user_id = auth.uid());
-- No write policy on admin_users: add admins from the SQL editor only.
