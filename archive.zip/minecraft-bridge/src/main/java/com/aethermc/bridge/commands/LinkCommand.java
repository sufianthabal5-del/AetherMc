package com.aethermc.bridge.commands;

import com.aethermc.bridge.api.ApiClient;
import com.google.gson.JsonObject;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class LinkCommand implements CommandExecutor {
    private final Plugin plugin;
    private final ApiClient api;

    public LinkCommand(Plugin plugin, ApiClient api) { this.plugin = plugin; this.api = api; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        if (args.length != 1) { p.sendMessage(ChatColor.YELLOW + "Usage: /link <code> (get the code on the website, Account page)"); return true; }
        JsonObject body = new JsonObject();
        body.addProperty("code", args[0]);
        body.addProperty("uuid", p.getUniqueId().toString());
        body.addProperty("name", p.getName());
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            String msg;
            try { api.post("/plugin-link", body.toString()); msg = ChatColor.GREEN + "Linked! Your game account is now connected to the website."; }
            catch (Exception e) { msg = ChatColor.RED + "Could not link: invalid or expired code, or account already linked."; }
            final String out = msg;
            Bukkit.getScheduler().runTask(plugin, () -> p.sendMessage(out));
        });
        return true;
    }
}
