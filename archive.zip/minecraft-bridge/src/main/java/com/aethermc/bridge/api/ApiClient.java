package com.aethermc.bridge.api;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class ApiClient {
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private final String base;
    private final String key;

    public ApiClient(String base, String key) {
        this.base = base.replaceAll("/+$", "");
        this.key = key;
    }

    public boolean configured() { return key != null && key.length() >= 24; }

    public String get(String path) throws IOException, InterruptedException {
        return send(HttpRequest.newBuilder(URI.create(base + path)).GET());
    }

    public String post(String path, String json) throws IOException, InterruptedException {
        return send(HttpRequest.newBuilder(URI.create(base + path)).header("content-type", "application/json").POST(HttpRequest.BodyPublishers.ofString(json)));
    }

    private String send(HttpRequest.Builder b) throws IOException, InterruptedException {
        HttpResponse<String> r = http.send(b.header("x-api-key", key).timeout(Duration.ofSeconds(15)).build(), HttpResponse.BodyHandlers.ofString());
        if (r.statusCode() >= 300) throw new IOException("HTTP " + r.statusCode() + ": " + r.body());
        return r.body();
    }
}
