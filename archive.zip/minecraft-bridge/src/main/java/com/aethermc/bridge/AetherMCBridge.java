package com.aethermc.bridge;

import com.aethermc.bridge.api.ApiClient;
import com.aethermc.bridge.commands.LinkCommand;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Instant;
import java.util.List;
import java.util.regex.Pattern;

public class AetherMCBridge extends JavaPlugin implements Listener {
    private static final Pattern NAME = Pattern.compile("^[A-Za-z0-9_.]{1,20}$");
    private ApiClient api;
    private Economy econ;
    private Statistic playStat;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        api = new ApiClient(getConfig().getString("api-url", ""), getConfig().getString("api-key", ""));
        if (!api.configured()) { getLogger().severe("api-key is missing or too short. Set it in config.yml, then restart."); }
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider(); else getLogger().warning("No Vault economy found; balances will be 0.");
        for (String n : new String[]{"PLAY_ONE_MINUTE", "PLAY_TIME"}) {
            try { playStat = Statistic.valueOf(n); break; } catch (IllegalArgumentException ignored) { }
        }
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("link").setExecutor(new LinkCommand(this, api));
        long sync = Math.max(15, getConfig().getLong("sync-seconds", 60)) * 20L;
        long deliver = Math.max(5, getConfig().getLong("delivery-seconds", 10)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, this::syncAll, 100L, sync);
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, this::pollDeliveries, 100L, deliver);
        registerVotifier();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        JsonObject one = snapshot(e.getPlayer());
        JsonArray arr = new JsonArray();
        arr.add(one);
        push(arr);
    }

    private int stat(Player p, Statistic s) {
        try { return s == null ? 0 : p.getStatistic(s); } catch (Exception e) { return 0; }
    }

    private JsonObject snapshot(Player p) {
        JsonObject o = new JsonObject();
        o.addProperty("uuid", p.getUniqueId().toString());
        o.addProperty("name", p.getName());
        o.addProperty("playtime_seconds", stat(p, playStat) / 20);
        o.addProperty("kills", stat(p, Statistic.PLAYER_KILLS));
        o.addProperty("deaths", stat(p, Statistic.DEATHS));
        o.addProperty("mob_kills", stat(p, Statistic.MOB_KILLS));
        o.addProperty("balance", econ != null ? econ.getBalance(p) : 0);
        return o;
    }

    // Runs on the main thread (statistics must be read there); the HTTP call is async.
    private void syncAll() {
        JsonArray arr = new JsonArray();
        for (Player p : Bukkit.getOnlinePlayers()) arr.add(snapshot(p));
        push(arr);
    }

    private void push(JsonArray players) {
        JsonObject server = new JsonObject();
        server.addProperty("players", Bukkit.getOnlinePlayers().size());
        server.addProperty("max_players", Bukkit.getMaxPlayers());
        server.addProperty("version", Bukkit.getMinecraftVersion());
        server.addProperty("tps", Math.min(20.0, Bukkit.getTPS()[0]));
        JsonObject body = new JsonObject();
        body.add("server", server);
        body.add("players", players);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            try { api.post("/plugin-sync", body.toString()); }
            catch (Exception e) { getLogger().warning("Sync failed: " + e.getMessage()); }
        });
    }

    private void pollDeliveries() {
        if (!api.configured()) return;
        try {
            JsonArray items = JsonParser.parseString(api.get("/plugin-deliveries")).getAsJsonArray();
            if (items.isEmpty()) return;
            Bukkit.getScheduler().runTask(this, () -> runDeliveries(items));
        } catch (Exception e) { getLogger().warning("Delivery poll failed: " + e.getMessage()); }
    }

    private void runDeliveries(JsonArray items) {
        JsonArray done = new JsonArray(), failed = new JsonArray();
        for (JsonElement el : items) {
            JsonObject d = el.getAsJsonObject();
            String id = d.get("id").getAsString(), name = d.get("mc_name").getAsString(), cmd = d.get("command").getAsString();
            if (!NAME.matcher(name).matches()) { failed.add(id); continue; }
            if (Bukkit.getPlayerExact(name) == null) continue; // stays pending until the player is online
            boolean ok;
            try { ok = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd); } catch (Exception e) { ok = false; }
            (ok ? done : failed).add(id);
        }
        if (done.isEmpty() && failed.isEmpty()) return;
        JsonObject body = new JsonObject();
        body.add("done", done);
        body.add("failed", failed);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            try { api.post("/plugin-deliveries", body.toString()); }
            catch (Exception e) { getLogger().warning("Delivery ack failed: " + e.getMessage()); }
        });
    }

    // NuVotifier is optional, so its event class is looked up by name at runtime.
    @SuppressWarnings("unchecked")
    private void registerVotifier() {
        try {
            Class<? extends Event> c = (Class<? extends Event>) Class.forName("com.vexsoftware.votifier.model.VotifierEvent");
            getServer().getPluginManager().registerEvent(c, this, EventPriority.NORMAL, (l, ev) -> {
                try {
                    Object vote = ev.getClass().getMethod("getVote").invoke(ev);
                    String user = (String) vote.getClass().getMethod("getUsername").invoke(vote);
                    String site = (String) vote.getClass().getMethod("getServiceName").invoke(vote);
                    onVote(user, site);
                } catch (Exception ex) { getLogger().warning("Vote handling failed: " + ex.getMessage()); }
            }, this);
        } catch (ClassNotFoundException e) { getLogger().info("NuVotifier not found; vote sync disabled."); }
    }

    private void onVote(String user, String site) {
        if (user == null || !NAME.matcher(user).matches()) return;
        JsonObject body = new JsonObject();
        body.addProperty("name", user);
        body.addProperty("site", site == null ? "" : site);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            try { api.post("/plugin-vote", body.toString()); } catch (Exception e) { getLogger().warning("Vote sync failed: " + e.getMessage()); }
        });
        List<String> cmds = getConfig().getStringList("vote-commands");
        if (!cmds.isEmpty()) Bukkit.getScheduler().runTask(this, () -> { for (String c : cmds) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c.replace("{player}", user)); });
    }
}
