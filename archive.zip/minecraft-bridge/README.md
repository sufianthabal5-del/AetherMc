# AetherMC Bridge plugin

Build: `mvn package` (Java 17+). The jar is in `target/`. Put it in your server's `plugins/` folder.
Needs Vault + EssentialsX. NuVotifier is optional (votes are synced if present).
Set `api-url` and `api-key` in `plugins/AetherMCBridge/config.yml`, then restart.

What it does: pushes server status and online-player stats every minute, runs paid-order commands for players who are online, handles `/link <code>`, and forwards votes.
